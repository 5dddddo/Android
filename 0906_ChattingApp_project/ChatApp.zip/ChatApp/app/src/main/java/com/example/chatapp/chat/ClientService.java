package com.example.chatapp.chat;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ClientService extends Service {

    IBinder mBinder = new MyBinder();
    private Socket socket;
    BufferedReader br;
    PrintWriter out;
    InputStreamReader isr;
    String clientId;
    BlockingQueue blockingQueue = new ArrayBlockingQueue(10);

    public ClientService() {    }

    class ClientSendRunnable implements Runnable {
        BlockingQueue blockingQueue;
        ClientSendRunnable(BlockingQueue blockingQueue) {
            this.blockingQueue = blockingQueue;
        }

        @Override
        public void run() {
            while (true) {
                try {
                    String msg = (String) blockingQueue.take();
                    Log.i("ChattingClientError", "blocking queue send: " + msg);
                    out.println(msg);
                    out.flush();
                } catch (Exception e) {
                    Log.i("ChattingClientError", "blocking queue 문제 : " + e.toString());
                }
            }
        }
    }

    class ClientReceiveRunnable implements Runnable {
        Intent receiveIntent = new Intent();
        @Override
        public void run() {
            try {
                try {
                    // 서버와 연결
                    socket = new Socket("70.12.115.57", 8000);
                    Log.i("ChattingClientConnect", "서버 연결 성공!!");
                    br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    out = new PrintWriter(socket.getOutputStream());
                } catch (Exception e) {
                    Log.i("ChattingClientError", e.toString());
                }
                out.println("/@CLID " + clientId);
                out.flush();

                /////////////자이제 시작이야
                String line = "";
                while ((line = br.readLine()) != null) {
                    Log.i("ChattingClient", "서버로 받는 데이터 : " + line);

                    String roomList[] = line.split(",");

                    if (roomList[0].equals("ROLI")) {
                        ComponentName cname = new ComponentName("com.example.chattapp",
                                "com.example.chatapp.chat.ChattingWaitingRoom");
                        receiveIntent.setComponent(cname);
                        receiveIntent.putExtra("RoomList", line);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(receiveIntent);

                    } else if (roomList[0].equals("CHAT")) {
                        ComponentName cname = new ComponentName("com.example.chattapp",
                                "com.example.chatapp.chat.ChattingClient");
                        receiveIntent.setComponent(cname);
                        receiveIntent.putExtra("CHAT", line);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(receiveIntent);
                    }
                }
            } catch (Exception e) {
                Log.i("ChattingClientError", "Receive 문제 : " + e.toString());
            }
        }
    }

    public void clientToServer(String roomNum, String msg) {
        if (msg.equals("enter")) {
            blockingQueue.add("/@ENRO," + roomNum);
        } else if (roomNum.equals("MKRO")) {
            blockingQueue.add("/@MKRO," + msg);
        } else {
            blockingQueue.add("/@CHAT," + roomNum + "," + msg);
        }
    }

    class MyBinder extends Binder {
        ClientService getService() {
            return ClientService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // 서비스에서 가장 먼저 호출됨(최초에 한번만)
        Log.i("serviceClient", "서비스 시작 , 서버랑 연결 시작.");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 서비스가 호출될 때마다 실행
        Intent getLoginIntent = intent;
        clientId = (String) getLoginIntent.getExtras().get("ID");

        ClientReceiveRunnable receiveRunnable = new ClientReceiveRunnable();
        ClientSendRunnable sendRunnable = new ClientSendRunnable(blockingQueue);
        Thread thread1 = new Thread(receiveRunnable);
        Thread thread2 = new Thread(sendRunnable);
        thread1.start();
        thread2.start();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // 서비스가 종료될 때 실행

    }

}
