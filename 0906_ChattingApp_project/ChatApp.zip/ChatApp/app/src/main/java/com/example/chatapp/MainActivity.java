
package com.example.chatapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Room implements Parcelable {
    String roomTitle;
    int roomNum;

    public String getRoomTitle() {
        return roomTitle;
    }

    public void setRoomTitle(String roomTitle) {
        this.roomTitle = roomTitle;
    }

    public int getRoomNum() {
        return roomNum;
    }

    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }

    public Room() {
    }

    public Room(int roomNum, String roomTitle) {
        this.roomNum = roomNum;
        this.roomTitle = roomTitle;
    }

    protected Room(Parcel parcel) {
        roomTitle = parcel.readString();
        roomNum = parcel.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        try {
            parcel.writeString(roomTitle);
            parcel.writeInt(roomNum);

        } catch (Exception e) {
        }
    }

    public static final Creator<Room> CREATOR = new Creator<Room>() {
        @Override
        public Room createFromParcel(Parcel parcel) {
            return new Room(parcel);
        }

        @Override
        public Room[] newArray(int i) {
            return new Room[i];
        }
    };

}

class RoomManager {
    List<Room> roomList = new ArrayList<Room>();

    public List<Room> getRoomList() {
        return roomList;
    }

    public boolean isExitRoom(int roomNum) {
        boolean flag = false;
        for (Room room : roomList) {
            if (room.getRoomNum() == roomNum) {
                flag = true;
            }
        }
        return flag;
    }

    public void addRoom(Room room) {
        roomList.add(room);
    }


}

public class MainActivity extends AppCompatActivity {
    private boolean flag = false;
    private Socket socket;
    private BufferedReader br;
    private PrintWriter out;

    private String nickName;
    RoomManager roomManager = new RoomManager();
    RoomListAdapter roomListAdapter = new RoomListAdapter();
    ListView listview;
    TextView tv;
    String clientId;
    ClientService clientService;
    Boolean isService = false;
    BlockingQueue q = new ArrayBlockingQueue(30);

    public void makeRoomListView() {
        tv.setText("채팅방을 선택하세요!");
        roomListAdapter.setRoomList(roomManager.getRoomList());
        listview.setAdapter(roomListAdapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showDialog("설정");
        listview = (ListView) findViewById(R.id.listview);
        tv = (TextView)findViewById(R.id.textView);


        ServiceConnection conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                ClientService.MyBinder mb = (ClientService.MyBinder) iBinder;
                clientService = mb.getService();
                isService = true;
            }

            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                isService = false;
            }
        };

        Intent intent2 = new Intent(MainActivity.this, ClientService.class);
        bindService(intent2, conn, Context.BIND_ABOVE_CLIENT);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int cur = item.getItemId();
        switch (cur) {
            case R.id.addRoom:
                final EditText editText = new EditText(MainActivity.this);
                android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("방 만들라꼬? ㅎㅎ");
                dialog.setMessage("원하는 방 제목을 적어주세요.");
                dialog.setView(editText);
                dialog.setPositiveButton("방만들기", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i("ChattingClientMkdir", "blockingQueue.add하즈아 : " + "/@MKRO," + editText.getText().toString());
                        clientService.clientToServer("MKRO", editText.getText().toString());
                    }
                });
                dialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                dialog.show();
                break;
            case R.id.setting:
                Toast.makeText(this, "닉네임 수정", Toast.LENGTH_SHORT).show();
                showDialog("수정");
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void showDialog(String msg) {
        final EditText et = new EditText(MainActivity.this);
        final AlertDialog.Builder dialog =
                new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle("Nickname 설정");
        dialog.setMessage("사용할 Nickname을 입력하세요");
        dialog.setView(et);
        dialog.setPositiveButton(msg, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                nickName = et.getText().toString();
                Intent intent = new Intent(getApplicationContext(), ClientService.class);
                intent.putExtra("nickName", nickName);
                ComponentName cname = new ComponentName("com.example.chatapp", "com.example.chatapp.ClientService");
                intent.setComponent(cname);
                startService(intent);
            }
        });
        dialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        dialog.show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String line = (String) intent.getExtras().get("ROOMLIST");
        String[] roomlist = line.split(",");
        if (!roomlist[1].equals("0")) {
            int rsize = Integer.parseInt(roomlist[1]);
            for (int i = 2; i < rsize + 2; ) {
                if (roomManager.isExitRoom(Integer.parseInt(roomlist[i]))) {
                    i += 2;
                } else {
                    Room room = new Room(Integer.parseInt(roomlist[i]), roomlist[i++]);
                    roomManager.addRoom(room);
                }
            }
            makeRoomListView();
        }
    }
}
