package com.example.chatapp;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ClientService extends Service {
    MyBinder myBinder = new MyBinder();
    private Socket socket;
    BufferedReader br;
    PrintWriter out;
    String cName;
    BlockingQueue blockingQueue = new ArrayBlockingQueue(10);

    class ReceiveRunnable implements Runnable {
        Intent receiveIntent = new Intent();

        @Override
        public void run() {
            try {
                socket = new Socket("70.12.115.57", 8000);
                br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream());

                out.println("/@NICKNAME" + cName);
                out.flush();

                String line = "";
                while ((line = br.readLine()) != null) {
                    Log.i("ClientServiceReceive", "서버가 보낸 msg : " + line);
                    String roomList[] = line.split(",");
                    if (roomList[0].equals("ROOMLIST")) {
                        ComponentName cname = new ComponentName("com.example.chatapp",
                                "com.example.chatapp.MainActivity");
                        receiveIntent.setComponent(cname);
                        receiveIntent.putExtra("ROOMLIST", line);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(receiveIntent);

                    } else if (roomList[0].equals("CHAT")) {
                        ComponentName cname = new ComponentName("coom.example.chatapp",
                                "com.example.chatapp.ChattingClient");
                        receiveIntent.setComponent(cname);
                        receiveIntent.putExtra("Chat", line);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        receiveIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(receiveIntent);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class SendRunnable implements Runnable {
        BlockingQueue q;

        public SendRunnable(BlockingQueue q) {
            this.q = q;
        }

        @Override
        public void run() {
            try {
                String tmp = q.take().toString();
                out.println(tmp);
                out.flush();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public ClientService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("ClientServiceStart", "서비스 시작");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("ClientService", "StartCommand 시작");
        Intent getIntent = intent;
        cName = (String) getIntent.getExtras().get("nickName");
        ReceiveRunnable receiveRunnable = new ReceiveRunnable();
        SendRunnable sendRunnable = new SendRunnable(blockingQueue);
        Thread thread1 = new Thread(receiveRunnable);
        Thread thread2 = new Thread(sendRunnable);
        thread1.start();
        thread2.start();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    public void clientToServer(String roomNum, String msg) {
        if (msg.equals("enter")) {
            blockingQueue.add("/@ENRO," + roomNum);
        } else if (roomNum.equals("MKRO")) {
            blockingQueue.add("/@MKRO," + msg);
        } else {
            blockingQueue.add("/@CHAT," + roomNum + "," + msg);
        }
    }

    class MyBinder extends Binder {
        ClientService getService() {
            return ClientService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return myBinder;
    }


}
