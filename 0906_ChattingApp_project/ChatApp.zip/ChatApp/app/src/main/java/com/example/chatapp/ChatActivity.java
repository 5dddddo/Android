
package com.example.chatapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChatActivity extends AppCompatActivity {
    private boolean flag = false;
    private TextView tv;
    private EditText sendMsg;
    private Button sendBtn;
    private ScrollView sv;

    private Socket socket;
    private BufferedReader br;
    private PrintWriter out;
    private String nickName;
    ExecutorService executorService = Executors.newCachedThreadPool();
    BlockingQueue q = new ArrayBlockingQueue(30);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showDialog("설정");

        tv = (TextView) findViewById(R.id.textView);
        sendMsg = (EditText) findViewById(R.id.sendMsg);
        sendBtn = (Button) findViewById(R.id.sendBtn);

        Handler handler = new Handler() {
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                Bundle bundle = new Bundle();
                bundle = msg.getData();
                String receiveMsg = bundle.getString("receiveMsg");
                tv.append(receiveMsg + "\n");
            }
        };

//        final ReceiveRunnable receiveRunnable = new ReceiveRunnable(handler);
//        executorService.execute(receiveRunnable);
//
//        sendBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                q.add(nickName + "> " + sendMsg.getText().toString());
//                if (flag == true) {
//                    SendRunnable sendRunnable = new SendRunnable(q);
//                    executorService.execute(sendRunnable);
//                } else {
//                    Toast.makeText(MainActivity.this, "Server 접속 실패", Toast.LENGTH_SHORT).show();
//                    executorService.execute(receiveRunnable);
//                }
//                sendMsg.setText("");
//            }
//        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int curid = item.getItemId();
        switch (curid) {
            case R.id.addRoom:
//                q.add("/SHOWROOM/");
//                SendRunnable s = new SendRunnable(q);
                Toast.makeText(this, "추가하기", Toast.LENGTH_SHORT).show();
                break;
            case R.id.setting:
                Toast.makeText(this, "닉네임 수정", Toast.LENGTH_SHORT).show();
                showDialog("수정");
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void showDialog(String msg) {
        final EditText et = new EditText(ChatActivity.this);
        final AlertDialog.Builder dialog =
                new AlertDialog.Builder(ChatActivity.this);
        dialog.setTitle("Nickname 설정");
        dialog.setMessage("사용할 Nickname을 입력하세요");
        dialog.setView(et);
        dialog.setPositiveButton(msg, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
//                String tmp = nickName;
                nickName = et.getText().toString();

            }
        });
        dialog.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        dialog.show();
    }

}
